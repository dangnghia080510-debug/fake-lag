package com.fakelag.cryhard8;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.os.Build;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * LicenseManager — bắt buộc có key hợp lệ từ server mới được dùng app.
 * Server: https://game-license-server-2dhq.onrender.com
 */
public class LicenseManager {

    public interface Callback {
        void onSuccess(long remainingMs);
        void onFailure(String error);
    }

    private static final String PREFS = "game_license";
    private static final String PREF_KEY       = "saved_key";
    private static final String PREF_EXPIRE_AT = "expire_at";

    /** URL server license — không đổi trừ khi deploy server mới */
    public static final String LICENSE_SERVER = "https://game-license-server-2dhq.onrender.com";

    private final Context context;
    private final String serverUrl;

    public LicenseManager(Context context) {
        this(context, LICENSE_SERVER);
    }

    public LicenseManager(Context context, String serverUrl) {
        this.context   = context.getApplicationContext();
        this.serverUrl = serverUrl.replaceAll("/$", "");
    }

    // ── PUBLIC API ─────────────────────────────────────────────────────────────

    /** Kích hoạt key lần đầu (hoặc thử lại). Gọi khi user nhập key. */
    public void activate(String key, Callback callback) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("key",         key.trim().toUpperCase());
                body.put("device_id",   getDeviceId());
                body.put("device_name", getDeviceName());

                JSONObject res = post("/api/activate", body);
                if (res.optBoolean("success")) {
                    long remaining = res.optLong("remaining_ms");
                    saveKey(key.trim().toUpperCase(), System.currentTimeMillis() + remaining);
                    runMain(() -> callback.onSuccess(remaining));
                } else {
                    String err = res.optString("error", "Lỗi không xác định");
                    runMain(() -> callback.onFailure(err));
                }
            } catch (Exception e) {
                runMain(() -> callback.onFailure("Không kết nối được server"));
            }
        }).start();
    }

    /** Kiểm tra license mỗi lần mở app. Gọi trong onCreate của MainActivity. */
    public void check(Callback callback) {
        String savedKey = getSavedKey();
        if (savedKey == null) {
            runMain(() -> callback.onFailure("Chưa có key — vui lòng nhập key"));
            return;
        }

        // Check local cache trước (tránh gọi server mỗi lần)
        long cachedExpire = getCachedExpire();
        if (cachedExpire > System.currentTimeMillis()) {
            runMain(() -> callback.onSuccess(cachedExpire - System.currentTimeMillis()));
            // Vẫn verify ngầm với server
            verifyInBackground(savedKey);
            return;
        }

        // Hết cache → gọi server
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("key",       savedKey);
                body.put("device_id", getDeviceId());

                JSONObject res = post("/api/check", body);
                if (res.optBoolean("valid")) {
                    long remaining = res.optLong("remaining_ms");
                    saveKey(savedKey, System.currentTimeMillis() + remaining);
                    runMain(() -> callback.onSuccess(remaining));
                } else {
                    clearKey();
                    String err = res.optString("error", "Key không hợp lệ");
                    runMain(() -> callback.onFailure(err));
                }
            } catch (Exception e) {
                // Offline → dùng cache nếu còn hạn
                if (cachedExpire > System.currentTimeMillis()) {
                    runMain(() -> callback.onSuccess(cachedExpire - System.currentTimeMillis()));
                } else {
                    runMain(() -> callback.onFailure("Không kết nối được server và key đã hết hạn"));
                }
            }
        }).start();
    }

    /** Kiểm tra ngầm (không block UI) */
    private void verifyInBackground(String key) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("key",       key);
                body.put("device_id", getDeviceId());
                JSONObject res = post("/api/check", body);
                if (res.optBoolean("valid")) {
                    saveKey(key, System.currentTimeMillis() + res.optLong("remaining_ms"));
                } else {
                    clearKey();
                }
            } catch (Exception ignored) {}
        }).start();
    }

    public boolean hasKey()   { return getSavedKey() != null; }
    public void   clearKey()  { prefs().edit().clear().apply(); }

    public String getSavedKeyPublic() { return getSavedKey(); }

    public long getRemainingMs() {
        long exp = getCachedExpire();
        long now = System.currentTimeMillis();
        return exp > now ? exp - now : 0;
    }

    // ── UTILS ──────────────────────────────────────────────────────────────────

    private String getDeviceId() {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) return capitalize(model);
        return capitalize(manufacturer) + " " + model;
    }

    private String capitalize(String s) {
        return s == null || s.isEmpty() ? "" : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private void saveKey(String key, long expireAt) {
        prefs().edit().putString(PREF_KEY, key).putLong(PREF_EXPIRE_AT, expireAt).apply();
    }

    private String getSavedKey()    { return prefs().getString(PREF_KEY, null); }
    private long   getCachedExpire(){ return prefs().getLong(PREF_EXPIRE_AT, 0); }
    private SharedPreferences prefs(){ return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private void runMain(Runnable r) {
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(r);
    }

    // ── HTTP ───────────────────────────────────────────────────────────────────

    private JSONObject post(String path, JSONObject body) throws Exception {
        URL url = new URL(serverUrl + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300)
                ? conn.getInputStream()
                : conn.getErrorStream();
        if (is == null) {
            throw new Exception("HTTP " + code);
        }

        Scanner sc = new Scanner(is, "UTF-8");
        StringBuilder sb = new StringBuilder();
        while (sc.hasNextLine()) sb.append(sc.nextLine());
        sc.close();

        String raw = sb.toString().trim();
        if (raw.isEmpty()) {
            JSONObject fallback = new JSONObject();
            fallback.put("success", false);
            fallback.put("valid", false);
            fallback.put("error", "Server trả về rỗng (HTTP " + code + ")");
            return fallback;
        }
        return new JSONObject(raw);
    }
}
