# Hướng dẫn build APK (không cần Android Studio)

## Cách 1 — GitHub Actions (KHUYẾN NGHỊ, miễn phí)

1. Tạo tài khoản GitHub (nếu chưa có)
2. Tạo repo mới (Private cũng được)
3. Upload toàn bộ thư mục `fakelag-beta` lên repo
   - Có thể kéo thả zip giải nén, hoặc dùng GitHub Desktop / `git`
4. Vào tab **Actions** → chọn workflow **Build APK** → **Run workflow**
5. Đợi ~3–8 phút → vào run → **Artifacts** → tải `fakelag-debug-apk`
6. Giải nén ra file `.apk` → cài vào điện thoại

> Lần đầu có thể hơi lâu vì GitHub tải Android SDK.

---

## Cách 2 — Command line trên máy Windows / Linux / Mac

### A. Cài JDK 17
- Windows: https://adoptium.net (Temurin 17)
- Hoặc `winget install EclipseAdoptium.Temurin.17.JDK`

### B. Cài Android command-line tools
1. Tải: https://developer.android.com/studio#command-line-tools-only
2. Giải nén, đặt cấu trúc:
   ```
   Android/Sdk/cmdline-tools/latest/bin/sdkmanager
   ```
3. Mở terminal:

```bash
# Windows (PowerShell) — chỉnh path cho đúng
$env:ANDROID_HOME="C:\Users\YourName\AppData\Local\Android\Sdk"
# Linux/Mac
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin

sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"
```

### C. Build

```bash
cd fakelag-beta

# Tạo local.properties
echo "sdk.dir=C:\\\\Users\\\\YourName\\\\AppData\\\\Local\\\\Android\\\\Sdk" > local.properties
# Linux: echo "sdk.dir=$HOME/Android/Sdk" > local.properties

# Windows dùng gradlew.bat
gradlew.bat assembleDebug

# Linux/Mac
chmod +x gradlew
./gradlew assembleDebug
```

APK nằm tại:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## Cách 3 — Dùng máy bạn có sẵn Android Studio (nếu sau này cài)

File → Open → chọn thư mục `fakelag-beta` → Build → Build Bundle(s) / APK(s) → Build APK(s)

---

## Lưu ý

- App đã gắn license server: `https://game-license-server-2dhq.onrender.com`
- Cần key hợp lệ mới bật Engine / Floating
- Debug APK ký bằng key debug mặc định (đủ để cài test)
- Muốn release APK ký chính chủ: cần keystore + `assembleRelease`
